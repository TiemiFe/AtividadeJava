/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.desafio;

import java.util.Scanner;
/**
 *
 * @author Admin
 */
public class Desafio {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println ("Informe um numero: ");
        int numero = scanner.nextInt();
        
        System.out.println("Tabela de quadrados de 1 a " + numero + ":");
        for (int i = 1; i <= numero; i++) {
            System.out.println(i + "² = " + (i * i));
        }
        scanner.close();
    }
}
