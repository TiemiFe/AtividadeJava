/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividadesoma;

/**
 *
 * @author Admin
 */
public class AtividadeSoma {

    public static void main(String[] args) {
        int soma = 0;
        for (int i = 1; i <= 50; i++) {
            soma += i;
        }
        System.out.println("A soma dos numeros de 1 a 50 será: " + soma);
        
        
    }
}
